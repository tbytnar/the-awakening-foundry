Hooks.on('ready', () => {
	CONFIG.DND5E.weaponProperties['covert'] = 'Covert';
	CONFIG.DND5E.weaponProperties['auto'] = 'Auto';
    CONFIG.DND5E.weaponProperties['burst'] = 'Burst';
    CONFIG.DND5E.weaponProperties['doubletap'] = 'Double Tap';
});